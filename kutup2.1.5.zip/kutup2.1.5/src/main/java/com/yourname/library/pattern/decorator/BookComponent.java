package com.yourname.library.pattern.decorator;

public interface BookComponent {
    String getDescription();
}
