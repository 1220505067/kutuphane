package com.yourname.library.pattern.observer;

public interface IInventoryObserver {
    void update();
}
